﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;

public class Employee
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Position { get; set; }
    public string Room { get; set; }
    public int ComputerId { get; set; }
}

public class Computer
{
    public int Id { get; set; }
    public string Model { get; set; }
    public string SerialNumber { get; set; }
    public DateTime PurchaseDate { get; set; }
    public DateTime? ReplacementDate { get; set; }
    public int EmployeeId { get; set; }
    public string Status { get; set; } = "Active";
}

public class Printer
{
    public int Id { get; set; }
    public string Model { get; set; }
    public string SerialNumber { get; set; }
    public string Room { get; set; }
    public DateTime PurchaseDate { get; set; }
    public DateTime? ReplacementDate { get; set; }
    public bool IsShared { get; set; }
    public string Status { get; set; } = "Active";
}

public class EquipmentReport
{
    public int RequiredComputers { get; set; }
    public int RequiredPrinters { get; set; }
    public List<string> RoomsWithoutPrinters { get; set; }
    public List<Computer> ComputersForReplacement { get; set; }
    public List<Printer> PrintersForReplacement { get; set; }
}

public class EquipmentManagementService
{
    public List<Employee> Employees { get; private set; }
    public List<Computer> Computers { get; private set; }
    public List<Printer> Printers { get; private set; }

    private readonly int _equipmentLifetimeYears = 5;

    public EquipmentManagementService()
    {
        Employees = new List<Employee>();
        Computers = new List<Computer>();
        Printers = new List<Printer>();
    }

    public EquipmentReport CalculateEquipmentNeeds()
    {
        var report = new EquipmentReport();
        
        report.RequiredComputers = Employees.Count - 
            Computers.Count(c => c.Status == "Active");
        
        var roomsWithEmployees = Employees.Select(e => e.Room).Distinct();
        var roomsWithPrinters = Printers
            .Where(p => p.Status == "Active")
            .Select(p => p.Room)
            .Distinct();
        
        report.RoomsWithoutPrinters = roomsWithEmployees
            .Except(roomsWithPrinters)
            .ToList();
        
        report.RequiredPrinters = report.RoomsWithoutPrinters.Count;
        
        var replacementDate = DateTime.Now.AddYears(-_equipmentLifetimeYears);
        report.ComputersForReplacement = Computers
            .Where(c => c.PurchaseDate <= replacementDate && c.Status == "Active")
            .ToList();
        
        report.PrintersForReplacement = Printers
            .Where(p => p.PurchaseDate <= replacementDate && p.Status == "Active")
            .ToList();
        
        return report;
    }

    public void AddEmployee(Employee employee)
    {
        employee.Id = Employees.Any() ? Employees.Max(e => e.Id) + 1 : 1;
        Employees.Add(employee);
    }

    public void AddComputer(Computer computer)
    {
        computer.Id = Computers.Any() ? Computers.Max(c => c.Id) + 1 : 1;
        Computers.Add(computer);
    }

    public void AddPrinter(Printer printer)
    {
        printer.Id = Printers.Any() ? Printers.Max(p => p.Id) + 1 : 1;
        Printers.Add(printer);
    }

    public bool RemoveEmployee(int employeeId)
    {
        var employee = Employees.FirstOrDefault(e => e.Id == employeeId);
        if (employee != null)
        {
            var computer = Computers.FirstOrDefault(c => c.EmployeeId == employeeId);
            if (computer != null)
            {
                computer.EmployeeId = 0;
            }
            
            Employees.Remove(employee);
            return true;
        }
        return false;
    }

    public bool RemoveComputer(int computerId)
    {
        var computer = Computers.FirstOrDefault(c => c.Id == computerId);
        if (computer != null)
        {
            Computers.Remove(computer);
            return true;
        }
        return false;
    }

    public bool RemovePrinter(int printerId)
    {
        var printer = Printers.FirstOrDefault(p => p.Id == printerId);
        if (printer != null)
        {
            Printers.Remove(printer);
            return true;
        }
        return false;
    }

    public bool UpdateEmployee(Employee updatedEmployee)
    {
        var employee = Employees.FirstOrDefault(e => e.Id == updatedEmployee.Id);
        if (employee != null)
        {
            employee.Name = updatedEmployee.Name;
            employee.Position = updatedEmployee.Position;
            employee.Room = updatedEmployee.Room;
            employee.ComputerId = updatedEmployee.ComputerId;
            return true;
        }
        return false;
    }

    public bool UpdateComputer(Computer updatedComputer)
    {
        var computer = Computers.FirstOrDefault(c => c.Id == updatedComputer.Id);
        if (computer != null)
        {
            computer.Model = updatedComputer.Model;
            computer.SerialNumber = updatedComputer.SerialNumber;
            computer.PurchaseDate = updatedComputer.PurchaseDate;
            computer.EmployeeId = updatedComputer.EmployeeId;
            computer.Status = updatedComputer.Status;
            return true;
        }
        return false;
    }

    public bool UpdatePrinter(Printer updatedPrinter)
    {
        var printer = Printers.FirstOrDefault(p => p.Id == updatedPrinter.Id);
        if (printer != null)
        {
            printer.Model = updatedPrinter.Model;
            printer.SerialNumber = updatedPrinter.SerialNumber;
            printer.Room = updatedPrinter.Room;
            printer.PurchaseDate = updatedPrinter.PurchaseDate;
            printer.IsShared = updatedPrinter.IsShared;
            printer.Status = updatedPrinter.Status;
            return true;
        }
        return false;
    }

    public List<Employee> SortEmployeesByRoom() => 
        Employees.OrderBy(e => e.Room).ThenBy(e => e.Name).ToList();
    
    public List<Employee> SortEmployeesByName() => 
        Employees.OrderBy(e => e.Name).ToList();
    
    public List<Computer> SortComputersByPurchaseDate() => 
        Computers.OrderBy(c => c.PurchaseDate).ToList();
    
    public List<Printer> SortPrintersByRoom() => 
        Printers.OrderBy(p => p.Room).ToList();

    public List<Employee> FilterEmployeesByRoom(string room) => 
        Employees.Where(e => e.Room == room).ToList();
    
    public List<Computer> FilterComputersByStatus(string status) => 
        Computers.Where(c => c.Status == status).ToList();
    
    public List<Computer> FilterComputersForReplacement() => 
        Computers.Where(c => c.PurchaseDate <= DateTime.Now.AddYears(-_equipmentLifetimeYears)).ToList();
    
    public List<Printer> FilterPrintersByRoom(string room) => 
        Printers.Where(p => p.Room == room).ToList();

    public void ExportToXml(string filePath)
    {
        var data = new EquipmentData
        {
            Employees = Employees,
            Computers = Computers,
            Printers = Printers
        };

        var serializer = new XmlSerializer(typeof(EquipmentData));
        using (var writer = new StreamWriter(filePath))
        {
            serializer.Serialize(writer, data);
        }
    }

    public void ImportFromXml(string filePath)
    {
        if (!File.Exists(filePath)) return;

        var serializer = new XmlSerializer(typeof(EquipmentData));
        using (var reader = new StreamReader(filePath))
        {
            var data = (EquipmentData)serializer.Deserialize(reader);
            Employees = data.Employees;
            Computers = data.Computers;
            Printers = data.Printers;
        }
    }

    public void GenerateReplacementReport(string filePath)
    {
        var report = CalculateEquipmentNeeds();
        
        var doc = new XmlDocument();
        var root = doc.CreateElement("EquipmentReplacementReport");
        doc.AppendChild(root);

        AddXmlElement(doc, root, "ReportDate", DateTime.Now.ToString("yyyy-MM-dd"));
        AddXmlElement(doc, root, "RequiredComputers", report.RequiredComputers.ToString());
        AddXmlElement(doc, root, "RequiredPrinters", report.RequiredPrinters.ToString());

        var roomsElement = doc.CreateElement("RoomsWithoutPrinters");
        foreach (var room in report.RoomsWithoutPrinters)
        {
            AddXmlElement(doc, roomsElement, "Room", room);
        }
        root.AppendChild(roomsElement);

        var computersElement = doc.CreateElement("ComputersForReplacement");
        foreach (var computer in report.ComputersForReplacement)
        {
            var compElement = doc.CreateElement("Computer");
            AddXmlElement(doc, compElement, "Id", computer.Id.ToString());
            AddXmlElement(doc, compElement, "Model", computer.Model);
            AddXmlElement(doc, compElement, "PurchaseDate", computer.PurchaseDate.ToString("yyyy-MM-dd"));
            computersElement.AppendChild(compElement);
        }
        root.AppendChild(computersElement);

        doc.Save(filePath);
    }

    private void AddXmlElement(XmlDocument doc, XmlElement parent, string name, string value)
    {
        var element = doc.CreateElement(name);
        element.InnerText = value;
        parent.AppendChild(element);
    }
}

[XmlRoot("EquipmentData")]
public class EquipmentData
{
    public List<Employee> Employees { get; set; }
    public List<Computer> Computers { get; set; }
    public List<Printer> Printers { get; set; }
}